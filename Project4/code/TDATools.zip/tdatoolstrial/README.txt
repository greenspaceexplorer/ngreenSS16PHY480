TDATools

This is the master repo for the TDATools software package, created at Duke University in 2014.

This repo contains software written by, in no particular order, John Harer, Rann Bar-On, Nate Strawn, Chris Tralie, Paul Bendich,
Alex Pieloch, and Jurgen Slaczedek.

We are extremely grateful to the DataRTG Summer 2014 Undergraduate Topology Group (Alex Pieloch, Carmen Cox, Marshall Ratliff, Derrick Nowak, David Moon, Aaron Park, and Matt
Farrell) for testing an early version of this package.

This package consists of:

1) java code, found in /bin/tda.jar

2) matlab functions, all in /src/MATLAB, some which interact with tda.jar and some which stand on their own.

